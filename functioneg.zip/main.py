def full_name(first_name,last_name):
  f_name=first_name.title()
  l_name=last_name.title()
  print(f"Hey {f_name} {l_name} !")

full_name("naila","iram")