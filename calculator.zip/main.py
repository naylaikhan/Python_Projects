def add(n1,n2):
  return n1+n2

def minus(n1,n2):
  return n1-n2

def mul(n1,n2):
  return n1*n2

def dev(n1,n2):
  return n1/n2

cal={
  "addition":add,
  "diff":minus,
  "product":mul,
  "divide":dev
}
print(cal["divide"])
