from replit import clear
bids={}
bidding_finished=False
while not bidding_finished:
  name=input("wht id your name :")
  price=int(input("What is your bid : $"))
  bids[name]=price
  should_cotinue=input("Are there any other bidder? Type 'yes' or 'no'.")
  if should_cotinue=="no":
    bidding_finished=True
  elif should_cotinue=="yes":
    clear()